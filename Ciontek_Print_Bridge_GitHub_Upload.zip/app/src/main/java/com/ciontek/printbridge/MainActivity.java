package com.ciontek.printbridge;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.Enumeration;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        TextView info = new TextView(this);
        info.setPadding(30,40,30,30);
        info.setText("Ciontek Print Bridge\\n\\nServer port: 8765\\nIP: " + localIp() +
                "\\n\\nΗ εφαρμογή δέχεται αναφορές εκτύπωσης από το Taxi Shift μέσω Wi‑Fi.");
        Button start = new Button(this);
        start.setText("Start Print Bridge");
        start.setOnClickListener(v -> {
            Intent i = new Intent(this, PrintBridgeService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);
            Toast.makeText(this,"Print Bridge ενεργό",Toast.LENGTH_SHORT).show();
        });
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.addView(info); l.addView(start); setContentView(l);
    }
    private String localIp(){
        try {
            Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces();
            while(en.hasMoreElements()){
                Enumeration<java.net.InetAddress> add=en.nextElement().getInetAddresses();
                while(add.hasMoreElements()){
                    java.net.InetAddress a=add.nextElement();
                    if(!a.isLoopbackAddress() && a instanceof Inet4Address) return a.getHostAddress();
                }
            }
        } catch(Exception ignored){}
        return "—";
    }
}
